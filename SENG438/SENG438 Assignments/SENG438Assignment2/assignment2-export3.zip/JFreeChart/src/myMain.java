

//import org.junit.*;
import org.junit.runner.JUnitCore;

public class myMain {
	public static void main() {
		// JUnitCore runner = new JUnitCore();
		JUnitCore.main("RangeTest.java", "getLowerBoundTest.java", "DataUtilitiesCreateNumberArray.java",
				"DataUtilitiesCalculateRowTotalTest.java", "DataUtilitesGetCumulativePercentagesTest.java",
				"DataUtilitiesCalculateColumnTotalTest.java");
	}
}